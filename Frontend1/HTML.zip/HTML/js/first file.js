// alert('if you want to confirm');
// document.write('<p>Welcome to my page</p>');
alert('hi hello welcome');



